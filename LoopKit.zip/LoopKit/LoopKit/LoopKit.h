//
//  LoopKit.h
//  LoopKit
//
//  Created by Nathan Racklyeft on 1/18/16.
//  Copyright © 2016 Nathan Racklyeft. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for LoopKit.
FOUNDATION_EXPORT double LoopKitVersionNumber;

//! Project version string for LoopKit.
FOUNDATION_EXPORT const unsigned char LoopKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoopKit/PublicHeader.h>


