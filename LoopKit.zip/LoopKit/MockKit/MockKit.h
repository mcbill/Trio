//
//  MockKit.h
//  MockKit
//
//  Created by Michael Pangburn on 12/20/18.
//  Copyright © 2018 LoopKit Authors. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MockKit.
FOUNDATION_EXPORT double MockKitVersionNumber;

//! Project version string for MockKit.
FOUNDATION_EXPORT const unsigned char MockKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MockKit/PublicHeader.h>


