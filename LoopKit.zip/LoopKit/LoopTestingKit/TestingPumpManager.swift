//
//  TestingPumpManager.swift
//  LoopTestingKit
//
//  Created by Michael Pangburn on 3/5/19.
//  Copyright © 2019 LoopKit Authors. All rights reserved.
//

import LoopKit


public protocol TestingPumpManager: PumpManager, TestingDeviceManager {
    var reservoirFillFraction: Double { get set }
    func injectPumpEvents(_ pumpEvents: [NewPumpEvent])
}
