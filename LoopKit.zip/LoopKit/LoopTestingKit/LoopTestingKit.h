//
//  LoopTestingKit.h
//  LoopTestingKit
//
//  Created by Michael Pangburn on 3/5/19.
//  Copyright © 2019 LoopKit Authors. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LoopTestingKit.
FOUNDATION_EXPORT double LoopTestingKitVersionNumber;

//! Project version string for LoopTestingKit.
FOUNDATION_EXPORT const unsigned char LoopTestingKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoopTestingKit/PublicHeader.h>


