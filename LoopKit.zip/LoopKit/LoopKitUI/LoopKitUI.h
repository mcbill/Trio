//
//  LoopKitUI.h
//  LoopKitUI
//
//  Created by Nathan Racklyeft on 1/28/18.
//  Copyright © 2018 LoopKit Authors. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LoopKitUI.
FOUNDATION_EXPORT double LoopKitUIVersionNumber;

//! Project version string for LoopKitUI.
FOUNDATION_EXPORT const unsigned char LoopKitUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoopKitUI/PublicHeader.h>


