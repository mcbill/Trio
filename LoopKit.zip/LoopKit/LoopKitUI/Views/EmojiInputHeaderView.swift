//
//  EmojiInputHeaderView.swift
//  LoopKit
//
//  Copyright © 2017 LoopKit Authors. All rights reserved.
//

import UIKit

class EmojiInputHeaderView: UICollectionReusableView, IdentifiableClass {
    @IBOutlet var titleLabel: UILabel!
}
