//
//  MockKitUI.h
//  MockKitUI
//
//  Created by Michael Pangburn on 12/20/18.
//  Copyright © 2018 LoopKit Authors. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MockKitUI.
FOUNDATION_EXPORT double MockKitUIVersionNumber;

//! Project version string for MockKitUI.
FOUNDATION_EXPORT const unsigned char MockKitUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MockKitUI/PublicHeader.h>


