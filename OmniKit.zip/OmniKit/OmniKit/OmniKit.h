//
//  OmniKit.h
//  OmniKit
//
//  Created by Pete Schwamb on 8/26/18.
//  Copyright © 2018 Pete Schwamb. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for OmniKit.
FOUNDATION_EXPORT double OmniKitVersionNumber;

//! Project version string for OmniKit.
FOUNDATION_EXPORT const unsigned char OmniKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OmniKit/PublicHeader.h>


