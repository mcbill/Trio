//
//  OmniKitUI.h
//  OmniKitUI
//
//  Created by Pete Schwamb on 8/26/18.
//  Copyright © 2018 Pete Schwamb. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for OmniKitUI.
FOUNDATION_EXPORT double OmniKitUIVersionNumber;

//! Project version string for OmniKitUI.
FOUNDATION_EXPORT const unsigned char OmniKitUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OmniKitUI/PublicHeader.h>


