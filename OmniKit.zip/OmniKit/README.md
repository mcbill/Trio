# OmniKit
Omnipod Eros PumpManager For Loop

## Status
Supported. Incorporated into Loop

## For more information
Please join loop zulipchat at https://loop.zulipchat.com/
